# 🎯 Breakout Solutions - Complete Implementation Guide

## ✅ All Breakouts Completed

This folder contains complete, production-quality solutions for all three breakouts with extensive comments for partner discussion.

---

## 📁 File Structure

```text
breakouts/
├── readme.md                    # Original assignment
├── starter_code.py              # Original starter code
├── requirements.txt             # Python dependencies
│
├── breakout1_log_design.py      # ✅ Breakout 1: Log design (with discussion points)
├── logger.py                    # ✅ Breakout 2: Custom logger module
├── breakout2_complete.py        # ✅ Breakout 2: Full API with logging
├── breakout3_complete.py        # ✅ Breakout 3: Health checks + Prometheus
│
└── SOLUTIONS.md                 # This file
```

---

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Test the Logger

```bash
python logger.py
```

**Expected Output:**
- Colored console logs
- `logs/ecommerce.log` file created
- Execution timing demonstration

### 3. Run Breakout 2 (Logging)

```bash
python breakout2_complete.py
```

**Test the API:**
```bash
# Terminal 1: Run the server
python breakout2_complete.py

# Terminal 2: Test endpoints
curl http://localhost:8000/products
curl http://localhost:8000/users
curl http://localhost:8000/error

# Watch logs in real-time
tail -f logs/ecommerce.log
```

### 4. Run Breakout 3 (Monitoring)

```bash
python breakout3_complete.py
```

**Test health checks:**
```bash
curl http://localhost:8000/health
curl http://localhost:8000/ready
curl http://localhost:8000/startup
curl http://localhost:8000/metrics  # Prometheus format
```

---

## 📋 Breakout 1: Log Design

**File:** `breakout1_log_design.py`

**What It Contains:**
- ✅ Designed log messages for ALL endpoints
- ✅ Log levels with rationale (DEBUG, INFO, WARNING, ERROR, CRITICAL)
- ✅ Context data specifications
- ✅ Security considerations (what NOT to log)
- ✅ Partner discussion questions throughout

**Key Discussion Points:**
1. When to use each log level?
2. What context data is essential for debugging?
3. Security: What should never be logged?
4. Performance: Will logging slow down the API?

**Time:** 10 minutes with partner

---

## 📋 Breakout 2: Structured Logging

**Files:** 
- `logger.py` - Custom logging module
- `breakout2_complete.py` - API with integrated logging

### Logger Module Features

✅ **Custom Logger Configuration**
- Specific logger name (prevents library pollution)
- File rotation (prevents disk space issues)
- Structured formatting with context
- JSON format option (for log aggregation)

✅ **Performance Tracking**
- `@log_execution_time` decorator
- Automatic slow query warnings
- Request/response timing in middleware

✅ **Security & Compliance**
- Audit logging for user data access
- Request ID tracking
- No sensitive data in logs

### API Integration

✅ **Middleware Logging**
- Request ID generation for tracing
- Automatic request/response logging
- Performance metrics collection

✅ **Endpoint Logging**
- Business event logging
- Error handling with context
- Low stock warnings
- Slow query detection

✅ **Error Handling**
- Global exception handler
- Structured error context
- Stack traces included

**Partner Discussion Points:**
1. Why use a custom logger instead of `print()`?
2. What is "structured logging"?
3. How does `logger.propagate = False` work?
4. Why log in middleware vs endpoints?

**Time:** 30 minutes

---

## 📋 Breakout 3: Health Checks + Monitoring

**File:** `breakout3_complete.py`

### Health Check Endpoints

✅ **Liveness Probe** (`/health`)
- Is the application alive?
- Fast and simple check
- No external dependencies
- K8s will restart if failing

✅ **Readiness Probe** (`/ready`)
- Is the application ready for traffic?
- Checks dependencies (DB, cache, APIs)
- Checks system resources
- Load balancer removes if failing

✅ **Startup Probe** (`/startup`)
- Has the application finished starting?
- One-time check for slow startups
- Prevents liveness failures during startup

### Prometheus Metrics

✅ **Request Metrics**
- `http_requests_total` - Counter of all requests
- `http_request_duration_seconds` - Histogram of response times
- `http_requests_in_progress` - Gauge of concurrent requests

✅ **Error Metrics**
- `http_errors_total` - Counter of errors by type

✅ **System Metrics**
- `system_cpu_usage` - CPU usage percentage
- `system_memory_usage` - Memory usage percentage
- `active_database_connections` - DB connection pool size

✅ **Business Metrics**
- `products_low_stock` - Number of products needing reorder
- `user_access_attempts` - Access attempts with success/denied

**Partner Discussion Points:**
1. What's the difference between /health, /ready, and /startup?
2. Why use metrics in addition to logs?
3. Counter vs Gauge vs Histogram - when to use each?
4. Should /metrics be public?

**Time:** 30 minutes

---

## 🎓 Learning Outcomes

After completing these breakouts, you understand:

### Logging
- ✅ Why logging is essential (vs print statements)
- ✅ Log levels and when to use each
- ✅ Structured logging with context
- ✅ Log rotation and file management
- ✅ Security considerations (PII, sensitive data)
- ✅ Performance tracking with decorators
- ✅ Request tracing with request IDs

### Monitoring
- ✅ Health check patterns (liveness, readiness, startup)
- ✅ Prometheus metrics types (Counter, Gauge, Histogram)
- ✅ System resource monitoring
- ✅ Business metrics tracking
- ✅ Difference between logs and metrics
- ✅ Observability principles

### Best Practices
- ✅ Middleware for cross-cutting concerns
- ✅ Decorators for reusable functionality
- ✅ Global exception handling
- ✅ Security and compliance logging
- ✅ Performance optimization techniques

---

## 🔧 Advanced Topics (For Further Exploration)

### Setting Up Prometheus + Grafana

**1. Install Prometheus**
```bash
# Mac
brew install prometheus

# Linux
wget https://github.com/prometheus/prometheus/releases/download/v2.45.0/prometheus-2.45.0.linux-amd64.tar.gz
```

**2. Configure Prometheus**

Create `prometheus.yml`:
```yaml
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'ecommerce_api'
    static_configs:
      - targets: ['localhost:8000']
    metrics_path: '/metrics'
```

**3. Start Prometheus**
```bash
prometheus --config.file=prometheus.yml
# Visit http://localhost:9090
```

**4. Install Grafana**
```bash
# Mac
brew install grafana

# Start Grafana
brew services start grafana
# Visit http://localhost:3000 (admin/admin)
```

**5. Add Prometheus Data Source**
- Grafana → Configuration → Data Sources
- Add Prometheus
- URL: `http://localhost:9090`

**6. Create Dashboard**

Useful queries:
```promql
# Request rate
rate(http_requests_total[5m])

# Average response time
rate(http_request_duration_seconds_sum[5m]) / rate(http_request_duration_seconds_count[5m])

# Error rate
rate(http_errors_total[5m])

# 95th percentile response time
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))

# CPU usage
system_cpu_usage

# Low stock products
products_low_stock
```

---

## 💡 Partner Discussion Exercises

### Exercise 1: Log Analysis
1. Run `breakout2_complete.py`
2. Make 20 requests to different endpoints
3. Open `logs/ecommerce.log`
4. Find:
   - Slowest request (look for response_time)
   - Failed authentication attempt
   - Low stock warning
   - Error with stack trace

### Exercise 2: Metrics Analysis
1. Run `breakout3_complete.py`
2. Visit `/metrics` endpoint
3. Make requests to different endpoints
4. Visit `/metrics` again
5. Discuss:
   - Which metrics changed?
   - What do the `_total` suffixes mean?
   - What's a histogram bucket?

### Exercise 3: Design Exercise
Design logging and monitoring for a new endpoint:
- `POST /orders` - Create an order
- What should be logged?
- What metrics should be tracked?
- What health checks are needed?
- When should alerts fire?

### Exercise 4: Production Readiness
Discuss with partner:
1. What's missing for production deployment?
2. How would you handle log aggregation?
3. What alerts would you set up?
4. How would you handle PII compliance?
5. What about rate limiting?

---

## 🐛 Troubleshooting

### Logs not appearing
**Solution:** Check `LogConfig.LOG_LEVEL` in `logger.py`
```python
LOG_LEVEL = logging.DEBUG  # See all logs
```

### Colors not showing
**Solution:** Use a modern terminal (Windows Terminal, iTerm2)

### /ready endpoint always failing
**Solution:** This is intentional! It has a 10% random failure rate to demonstrate monitoring.

### Prometheus metrics not updating
**Solution:** Make sure you're making requests to the API, not just refreshing /metrics

---

## 📚 Additional Resources

### Logging Best Practices
- [Python Logging Documentation](https://docs.python.org/3/library/logging.html)
- [Twelve-Factor App - Logs](https://12factor.net/logs)
- [Structured Logging Best Practices](https://www.structlog.org/)

### Monitoring Tools
- [Prometheus Documentation](https://prometheus.io/docs/)
- [Grafana Documentation](https://grafana.com/docs/)
- [OpenTelemetry](https://opentelemetry.io/)
- [Google SRE Book - Monitoring](https://sre.google/sre-book/monitoring-distributed-systems/)

### FastAPI
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [FastAPI Best Practices](https://github.com/zhanymkanov/fastapi-best-practices)

---

## ✅ Solution Checklist

### Breakout 1 ✅
- [x] Designed log messages for all endpoints
- [x] Documented log levels and rationale
- [x] Included context data specifications
- [x] Considered error scenarios
- [x] Addressed security concerns
- [x] Added partner discussion questions

### Breakout 2 ✅
- [x] Created `logger.py` with custom logger
- [x] File rotation configured
- [x] Structured logging implemented
- [x] Added logging to all endpoints
- [x] Performance tracking with decorators
- [x] Request ID tracking
- [x] Security audit logging
- [x] Global exception handling
- [x] Extensive comments for discussion

### Breakout 3 ✅
- [x] Liveness probe (`/health`)
- [x] Readiness probe (`/ready`)
- [x] Startup probe (`/startup`)
- [x] Prometheus metrics endpoint
- [x] Request metrics (Counter, Histogram)
- [x] System metrics (CPU, memory)
- [x] Business metrics (inventory, access)
- [x] Integration with logging
- [x] Partner discussion prompts

---

## 🎉 Congratulations

You've completed a production-quality implementation of:
- ✅ Structured logging with rotation
- ✅ Performance monitoring
- ✅ Health checks for orchestration
- ✅ Prometheus metrics collection
- ✅ Security and compliance logging

**These skills are directly applicable to real-world production systems!**

---

## 📧 Questions?

Review the extensive comments in each file - they contain detailed explanations and discussion points for partner learning.

**Remember:** The goal isn't just to make it work, but to UNDERSTAND why it works! 🎯
